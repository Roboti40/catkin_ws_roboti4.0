Phidgets interface kit ROS driver
=================================

This is the meta-ROS driver for Phidgets interface kit.  Since Phidgets interface kits are composed of digital inputs, digital outputs, and analog inputs, we can compose an IK driver by just launching the individual drivers together.  This package only contains a launch file that makes it convenient to launch an IK.
