# Phidget22 Python Package

A Python wrapper library for the Phidget22 C library.

This requires the Phidget22 libraries to be installed first.

See: https://www.phidgets.com/docs/Language_-_Python
